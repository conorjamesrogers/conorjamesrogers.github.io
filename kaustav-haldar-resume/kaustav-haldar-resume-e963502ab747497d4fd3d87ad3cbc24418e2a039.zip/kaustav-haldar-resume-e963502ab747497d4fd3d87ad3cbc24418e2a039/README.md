# To compile
```
npm install
npm run build
```

All stylesheets are tied together at index.css and all jade templates are tied together similiarly at index.jade.  

